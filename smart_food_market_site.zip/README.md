# Smart Food Market — Static MVP
See registration_en.html → main page smart_food_market_full_en_with_bot.html.
Deploy to Netlify/Vercel using provided config files.
